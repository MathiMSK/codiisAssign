import { createAnswer, getAnswer, getAnswerById, updateAnswer } from "../controller/answerController.js";
import express from "express";

const router = express.Router();

router.post("/create", createAnswer);
router.get("/get", getAnswer);
router.get("/getbyid", getAnswerById);
router.put("/update", updateAnswer);

export default router;

