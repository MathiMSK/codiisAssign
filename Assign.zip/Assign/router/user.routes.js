import {  genPdf, getingPdf, getingPdf2 } from "../controller/test1.js";
import {login, getFaculty, getStudentById, getStudent, facultyreg, stureg, getPdf} from "../controller/userController.js";
import express from "express";

const router = express.Router();

router.post("/facregister", facultyreg);
router.post("/sturegister", stureg);
router.post("/login", login);
router.get("/getstu", getStudent);
router.get("/getstubyid", getStudentById);
router.get("/getfac",getFaculty)
router.post("/getpdf",getPdf)
router.get("/getpdf1",getingPdf)
router.get("/getpdf11",getingPdf2)
router.get("/genpdf",genPdf)

export default router;
