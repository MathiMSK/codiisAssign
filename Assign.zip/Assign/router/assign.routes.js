import { createAssign ,getAssign} from "../controller/assignController.js";
import express from "express";
import auth from "../middleware/auth.js";

const router = express.Router();

router.post("/create",auth, createAssign);
router.get("/get", auth,getAssign);

export default router; 