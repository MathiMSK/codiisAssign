import fs from "fs"
import pdf from "html-pdf"
import puppeteer from "puppeteer"
import path from "path"
const __dirname = path.resolve(); 

export const getingPdf = async (req, res) => {
    const html = fs.readFileSync('index.html').toString()
    var options = { format: 'Letter' };

    pdf.create(html, options).toStream(function (err, stream) {
        if (err) {
            console.log(err);
            res.status(500).send("Some kind of error...");
            return;
        }
        stream.pipe(res)
    })

}

export const getingPdf2 = async (req, res) => {

try {
    const browser = await puppeteer.launch()
    const page = await browser.newPage()
    // page.goto('http://localhost:3000/api/answer/get')
    await page.goto(`${req.protocol}://${req.get('host')}`+"/api/user/genpdf",{
        waitUntil:"networkidle2"
    })
    await page.setViewport({width: 1680, height: 1050}); 
    const todayDate = new Date().toISOString().slice(0, 10)
    
    const pdfn= await page.pdf({
        path:`${path.join(__dirname, './files/pdfFiles','Student'+' '+'report'+' '+todayDate+'.pdf')}` ,
        format:"A4",
    })

    await browser.close()

    const pdfUrl=path.join(__dirname, './files/pdfFiles','Student'+' '+'report'+' '+todayDate+'.pdf')
     
    res.set({
        "Content-Type": "application/pdf",
        "Content-Length": pdfn.length,
    })

    res.sendFile(pdfUrl);

} catch (error) {
    console.log(error.message);
}
}


export const genPdf = async (req, res) => {
    res.sendFile(path.join(__dirname+'/index.html'));
}

