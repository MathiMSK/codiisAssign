import fs from "fs"
import pdf from "html-pdf"
import puppeteer from "puppeteer"
import path from "path"
const __dirname = path.resolve(); 
import QuickChart from "quickchart-js";
import { getAnswer } from "./answerController.js";

export const getingPdf = async (req, res) => {
    const qc = new QuickChart();
    qc.setConfig({
      type: 'bar',
      data: {
        labels: getAnswer.map((item) => item.answer),
        datasets: [
          {
            label: 'Dogs',
            data: [50, 60, 70, 180, 190],
          },
        ],
      },
      options: {
        scales: {
          yAxes: [
            {
              ticks: {
                callback: function (value) {
                  return '$' + value;
                },
              },
            },
          ],
        },
      },
    });
    // qc.setWidth(500).setHeight(300).setBackgroundColor('#0febc2');
    const url = await qc.getShortUrl()
    console.log(url);
}

export const getingPdf2 = async (req, res) => {

try {
    const browser = await puppeteer.launch()
    const page = await browser.newPage()
    await page.goto(`${req.protocol}://${req.get('host')}`+"/api/user/genpdf",{
        waitUntil:"networkidle0"
    })
    await page.setViewport({width: 1680, height: 1050}); 
    const todayDate = new Date().toISOString().slice(0, 10)
    
    const pdfn= await page.pdf({
        path:`${path.join(__dirname, './files/pdfFiles','Student'+' '+'report'+' '+todayDate+'.pdf')}` ,
        format:"A4",
    })

    await browser.close()

    const pdfUrl=path.join(__dirname, './files/pdfFiles','Student'+' '+'report'+' '+todayDate+'.pdf')
     
    res.set({
        "Content-Type": "application/pdf",
        "Content-Length": pdfn.length,
    })

    res.sendFile(pdfUrl);

} catch (error) {
    console.log(error.message);
}
}


export const genPdf = async (req, res) => {
    res.sendFile(path.join(__dirname+'/index.html'));
}

