import Answer from "../model/answerModel.js";
import Assign from "../model/assignModel.js";

export const createAnswer = async (req, res) => {
  let email = req.body.email;
  let userId = req.body.userId;
  let assignId = req.body.assignId;
  let assignName = req.body.assignName;
  let id = req.query.id;
  try {
    let answer = await Answer.findOne({ userId: userId, assignId: assignId });
    if (answer)
      return res
        .status(400)
        .json({ message: "You already attended this assignment" });

    let userAnswer = new Answer({
      assignName: assignName,
      userId: userId,
      assignId: assignId,
      email: email,
      selectedAnswer: req.body.selectedAnswer,
    });

    let markAns=await userAnswer.save();
    let founfCorrectAns= await Assign.findById(assignId);
    let mark=0
    if (markAns.selectedAnswer === founfCorrectAns.correctAnswer) {
        mark+=1;
    }
    await Answer.findByIdAndUpdate(markAns._id,{Marks:mark})

    let assign = await Assign.findById(assignId);
    if (assign.assignName === markAns.assignName) {
    markAns.attend = "true";
    } else {
    markAns.attend = "false";
    }
    await markAns.save();
    res.status(200).json({ message: "Answer added" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const getAnswer = async (req, res) => {
  try {
    let answer = await Answer.find().populate("userId").populate("assignId");
    res.status(200).json({ message: "Answer fetched", data: answer });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const getAnswerById = async (req, res) => {
  try {
    let answer = await Answer.findById(req.query.id);
    res.status(200).json({ message: "Answer fetched", data: answer });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// export const updateAnswer = async (req, res) => {
//     const { quesId, id } = req.query;
//     try {
//         let answer = await Answer.findById(id).populate("assignId");
        
//         if (answer.selectedAnswer === answer.assignId.correctAnswer) {
//             answer.Marks = 1;
//         }
//         console.log(answer, "answer");

//         let assign = await Assign.findById(quesId);

//         if (assign.assignName === answer.assignName) {
//         assign.attend = "true";
//         } else {
//         assign.attend = "false";
//         }
//         await assign.save();
//         await answer.save();
//         res.status(200).json({ message: "Answer updated" });
//     } catch (error) {
//         res.status(400).json({ message: error.message });
//     }
// };
