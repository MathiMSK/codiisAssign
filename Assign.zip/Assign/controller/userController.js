import User from "../model/userModel.js";
import bcrypt from "bcrypt";
import express from "express"
import jwt from "jsonwebtoken";
import { validateUser } from "../model/userModel.js";
import PDFDocument from "pdfkit"
import fs from "fs"
import path from "path";
const __dirname = path.resolve();
export const facultyreg = async (req, res) => {
    const saltRounds = 10;
    const val = validateUser(req.body);
    if (val) return res.status(400).json({ message: val.error });
    let email = req.body.email;
    let firstName = req.body.firstName;
    let lastName = req.body.lastName;
    
    let exUserEmail = await User.findOne({ email: email });
    if (exUserEmail)
      return res.status(400).json({ message: "email already register" });
    bcrypt.hash(req.body.password, saltRounds, async (err, hash) => {
      try {
        let register = new User({
          email: email?.toLowerCase(),
          password: hash,
          firstName: firstName,
          lastName: lastName,
          isFaculty:true,
        });
        let user = await register.save();
        res.status(201).json({ message: "Register success", userId: user._id });
      } catch (error) {
        res.status(400).json({ message: error.message });
      }
    });
  };

export const stureg = async (req, res) => {
    const saltRounds = 10;
    const val = validateUser(req.body);
    if (val) return res.status(400).json({ message: val.error });
    let email = req.body.email;
    let firstName = req.body.firstName;
    let lastName = req.body.lastName;
    let classs = req.body.class

    if(!classs) return res.status(400).json({ message: "please enter class" });
    
    let exUserEmail = await User.findOne({ email: email });
    if (exUserEmail)
      return res.status(400).json({ message: "email already register" });
    bcrypt.hash(req.body.password, saltRounds, async (err, hash) => {
      try {
        let register = new User({
          email: email?.toLowerCase(),
          password: hash,
          firstName: firstName,
          lastName: lastName,
          class:classs
        })
        let user = await register.save();
        res.status(201).json({ message: "Register success", userId: user._id });
      } catch (error) {
        res.status(400).json({ message: error.message });
      }
    });
  };

  export const login = async (req, res) => {
    let email = req.body.email?.toLowerCase();
    let foundUser = await User.findOne({ email: email });
    if (!req.body.email)
      return res.status(400).json({ message: "please enter email" });
    if (!req.body.password)
      return res.status(400).json({ message: "please enter password" });
    if (foundUser) {
    //   if (foundUser.isFaculty == false && foundUser.isActive == false)
    //     return res.status(400).json({ message: "your are not active user" });
    //   if (foundUser.isFaculty == false && foundUser.isBlock == true)
    //     return res.status(400).json({ message: "your are blocked user" });
      bcrypt.compare(req.body.password, foundUser.password, (err, result) => {
        if (result) {
          try {
            const token = jwt.sign({ id: foundUser?._id },
                 process.env.JWT, {
                        expiresIn: "12h",
            });
            res.header("auth-token", token).json({ message: "login successfully", token: token });
          } catch (error) {
            res.status(400).json({ message: error.message });
          }
        } else {
          res.status(400).json({ message: "please enter correct password" });
        }
      });
    } else {
      res.status(404).json({ message: "user not found" });
    }
  };

  export const getFaculty = async (req, res) => {
    try {
      let faculty = await User.find({ isFaculty: true });
      res.status(200).json({ message: "Faculty fetched", data: faculty });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  export const getStudent = async (req, res) => {
    try {
      let student = await User.find({ isFaculty: false });
      res.status(200).json({ message: "Student fetched", data: student });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  export const getStudentById = async (req, res) => {
    const { id } = req.query;
    try {
      let student = await User.findById(id).populate("AssignId");
      res.status(200).json({ message: "Student fetched", data: student });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

 export const getPdf = async (req, res) => {
  const doc = new PDFDocument()
  let filename = req.body.filename
  // Stripping special characters
  filename = encodeURIComponent(filename) + '.pdf'
  res.setHeader('Content-disposition', 'attachment; filename="' + filename + '"')
  res.setHeader('Content-type', 'application/pdf')
  const content = req.body.content
  doc.y = 300
  doc.file(path.join(__dirname, 'index.html'))
  doc.pipe(res)
  doc.end()
 }
 