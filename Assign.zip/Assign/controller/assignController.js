import Assign from "../model/assignModel.js";
import User from "../model/userModel.js";


export const createAssign = async (req, res) => {
  let option1 = req.body.option1;
  let option2 = req.body.option2;
  let option3 = req.body.option3;
  let option4 = req.body.option4;
  try {
    let userAssign = new Assign({
      assignName:req.body.assignName,
      question:req.body.question,
      option:{
        option1:option1,
        option2:option2,
        option3:option3,
        option4:option4,
      },
      correctAnswer:req.body.correctAnswer,
    });
    
      await userAssign.save();
      res.status(200).json({ message: "Assignment added" });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  };

  export const getAssign = async (req, res) => {
    let id = req.query.id;
    if(!id){
      return res.status(400).json({ message: "Please provide user id in query" });
    }
    try {
      let userFind= await User.findOne({_id:id,isFaculty:true})
      if(!userFind) return res.status(400).json({ message: "You are not a Authentic person" });
      const assign = await Assign.find()
      res.status(200).json({ message: "Assignment fetched", data: assign });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  export const getAssignById = async (req, res) => {
    try {
      let assign = await Assign.findById(req.params.id);
      res.status(200).json({ message: "Assignment fetched", data: assign });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }