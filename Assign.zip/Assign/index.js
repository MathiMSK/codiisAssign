import express from 'express'
import bodyParser from 'body-parser';
import mongoose from 'mongoose'
import cors from 'cors'
import dotenv from "dotenv"
import user from './router/user.routes.js'
import assign from './router/assign.routes.js'
import answer from './router/answer.routes.js'

dotenv.config()
const app= express();


app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
const port = process.env.PORT || 7349

mongoose.set('strictQuery', false);
mongoose.connect('mongodb://127.0.0.1:27017/Assignment', {
 useNewUrlParser: true,
 useUnifiedTopology: true
 })
.then(() => console.log('Connected to MongoDB...'))
.catch(err => console.error('Could not connect to MongoDB... '+err.message));

app.get("/",(req,res)=>{
    res.send("Welcome to CODIIS Assignment")
}) 

app.use("/api/user",user)
app.use("/api/assign",assign)
app.use("/api/answer",answer)

app.listen(port,()=>{
    console.log("Server connected to "+ port); 
})