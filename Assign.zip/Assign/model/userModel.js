import mongoose from "mongoose";

const user =  new mongoose.Schema({
    firstName:{
        type:String,
        required: true
    },
    lastName:{
        type:String,
        required: true
    },
    class:{
        type:String,
    },
    email:{
        type:String,
        required: true
    },
    password:{
        type:String,
    },
    isFaculty:{
        type:Boolean,
        default:false
    },
},  {
    timestamps: true
}
)

const validateUser=(user)=>{    
    let email=user.email
    if(!/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{3}$/.test(email)){
        return {error:"invalid email"}
    }
   
}

export {validateUser}

const User=mongoose.model('User',user)
export default User;