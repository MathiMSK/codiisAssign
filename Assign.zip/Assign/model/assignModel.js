import mongoose from "mongoose";

const assign =  new mongoose.Schema({
    assignName:{
        type:String,
        required: true
    },
    question:{
        type:String,
        required: true
    },
    option:{
    option1:{
        type:String,
    },
    option2:{
        type:String,
    },
    option3:{
        type:String,
    },
    option4:{
        type:String,
    },
    },
    correctAnswer:{
        type:String,
    },
    attend:{
        type:String,
        default:false
    }
},  {
    timestamps: true
}
)

const Assign=mongoose.model('Assign',assign)
export default Assign;