import mongoose from "mongoose";


const answer =  new mongoose.Schema({
    userId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    email:{
        type:String,
        required: true
    },
    assignName: {
        type:String,
        required: true
    },
    assignId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Assign',
        required: true,
    },
    selectedAnswer:{
        type:String,
    },
    Marks:{
        type:Number,
        default:0
    },
    attend:{
        type:Boolean,
        default:false
    }
},{
    timestamps: true
}
)

const Answer=mongoose.model('Answer',answer)
export default Answer;